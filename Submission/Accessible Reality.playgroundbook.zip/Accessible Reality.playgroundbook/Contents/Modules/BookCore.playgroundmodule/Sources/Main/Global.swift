//
//  Global.swift
//  BookCore
//
//  Created by Zheng on 4/11/21.
//

import UIKit

struct Global {
    static var configurationChanged: (() -> Void)?
}
