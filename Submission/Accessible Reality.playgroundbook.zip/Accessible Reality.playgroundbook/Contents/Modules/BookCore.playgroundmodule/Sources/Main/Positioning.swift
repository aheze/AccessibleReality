//
//  Positioning.swift
//  BookCore
//
//  Created by Zheng on 4/6/21.
//

import UIKit

struct Constants {
    static var cardContainerHeight = CGFloat(300)
    static var cardWidth = CGFloat(300)
}
struct Positioning {
    static var cardContainerHeight = Constants.cardContainerHeight
}


