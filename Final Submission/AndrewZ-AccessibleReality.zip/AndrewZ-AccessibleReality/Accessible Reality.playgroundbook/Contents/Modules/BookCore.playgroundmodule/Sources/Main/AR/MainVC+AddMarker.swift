//
//  MainVC+AddMarker.swift
//  BookCore
//
//  Created by Zheng on 4/6/21.
//

import UIKit
import ARKit

extension MainViewController {
    func addMarker(at boundingBox: CGRect, name: String, color: UIColor, soundFileName: String) -> Marker? {
        
        /// get horizontal distance
        let bottomLeftPoint = CGPoint(x: boundingBox.minX, y: boundingBox.maxY)
        let bottomRightPoint = CGPoint(x: boundingBox.maxX, y: boundingBox.maxY)
        let objectCenter = CGPoint(x: boundingBox.midX, y: boundingBox.midY)
        
        if
            let bottomLeftResult = makeRaycastQuery(at: bottomLeftPoint),
            let bottomRightResult = makeRaycastQuery(at: bottomRightPoint),
            let centerResult = makeRaycastQuery(at: objectCenter)
        {
            let bottomLeftRealWorldPosition = bottomLeftResult.worldTransform.columns.3
            let bottomRightRealWorldPosition = bottomRightResult.worldTransform.columns.3
            let line = bottomRightRealWorldPosition - bottomLeftRealWorldPosition
           
            let distance = max(0.1, CGFloat(length(line))) /// prevent too small
            
            let heightOverWidthRatio = boundingBox.height / boundingBox.width
            let height = distance * CGFloat(heightOverWidthRatio)
    
            let box = SCNBox(width: distance, height: height, length: height, chamferRadius: 0)
            let node = SCNNode(geometry: box)
            node.name = "BoxNode"
            
            let cubeColor = color.withAlphaComponent(0.8) /// make partially transparent because it encompasses the detected object
            let colorMaterial = SCNMaterial()
            colorMaterial.diffuse.contents = cubeColor
            box.materials = [colorMaterial]
            
            let anchor = ARAnchor(name: "Node Anchor", transform: centerResult.worldTransform)
            sceneView.session.add(anchor: anchor)
            
            let maxRadius = max(distance, height) / 2
            let marker = Marker(
                name: name,
                color: color,
                soundFileName: soundFileName,
                hasDescription: true,
                box: box,
                node: node,
                anchor: anchor,
                radius: Float(maxRadius)
            )
            placedMarkers.append(marker)
            
            return marker
        }
        
        return nil
    }
    
    func addMarker(at screenCoordinate: CGPoint, color: UIColor, soundFileName: String) -> Marker? {
        if let result = makeRaycastQuery(at: screenCoordinate) {
            
            let box = SCNBox(width: 0.1, height: 0.1, length: 0.1, chamferRadius: 0)
            let node = SCNNode(geometry: box)
            node.name = "BoxNode"
            
            let colorMaterial = SCNMaterial()
            colorMaterial.diffuse.contents = color
            box.materials = [colorMaterial]
            
            let anchor = ARAnchor(name: "Node Anchor", transform: result.worldTransform)
            sceneView.session.add(anchor: anchor)
            
            let marker = Marker(
                name: "Node",
                color: color,
                soundFileName: soundFileName,
                hasDescription: false,
                box: box,
                node: node,
                anchor: anchor,
                radius: 0.05
            )
            placedMarkers.append(marker)
            
            return marker
        }
        
        return nil
        
    }
    
    func makeRaycastQuery(at screenCoordinate: CGPoint) -> ARRaycastResult? {
        if
            let raycastQuery = sceneView.raycastQuery(
                from: screenCoordinate,
                allowing: .existingPlaneInfinite,
                alignment: .horizontal
            )
        {
            let results = sceneView.session.raycast(raycastQuery)
            return results.last
        }
        
        return nil /// nil if no result
        
    }
}
